<div id='top_course'>
    <h2>Top Courses</h2>
    <ul>
        <li>
            <a href="course_detail.php">
                <img src="imgs/courses/1.jpg" alt="">
                <h3>NodeJs Course for Beginners</h3>
                <h4>Price: Rs 500</h4>
                <h5>Teacher's Name: Rewant Pandey</h5>
            </a>
        </li>
        <li>
            <a href="#">
                <img src="imgs/courses/2.jpeg" alt="">
                <h3>Ultimate PHP and My SQL Web Development</h3>
                <h4>Price: Rs 550</h4>
                <h5>Teacher's Name: Rewant Pandey</h5>
            </a>
        </li>
        <li>
            <a href="#">
                <img src="imgs/courses/3.jpeg" alt="">
                <h3>Full Stack Web Developer Bootcamp</h3>
                <h4>Price: Rs 700</h4>
                <h5>Teacher's Name: Rewant Pandey</h5>
            </a>
        </li>
        <li>
            <a href="#">
                <img src="imgs/courses/4.jpeg" alt="">
                <h3>Graphic Design Crash Course</h3>
                <h4>Price: Rs 399</h4>
                <h5>Teacher's Name: Rewant Pandey</h5>
            </a>
        </li>
        <li>
            <a href="#">
                <img src="imgs/courses/5.jpg" alt="">
                <h3>Web Design Course</h3>
                <h4>Price: Rs 650</h4>
                <h5>Teacher's Name: Rewant Pandey</h5>
            </a>
        </li>
        <li>
            <a href="#">
                <img src="imgs/courses/6.jpg" alt="">
                <h3>Complete SEO Digital Marketing Course</h3>
                <h4>Price: Rs 700</h4>
                <h5>Teacher's Name: Rewant Pandey</h5>
            </a>
        </li><br clear='all' />
    </ul>
</div>
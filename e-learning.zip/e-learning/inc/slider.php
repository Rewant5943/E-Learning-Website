<div id='slider'>
    <img src="imgs/slider/1.jpg" >
</div>
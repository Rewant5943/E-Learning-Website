<div id='footer'>
    <ul>
        <li>
            <h2><span>Abo</span>ut Us</h2>
            <p>We recognize the importance of implementing the right solution for your business.
             We offer a wide range of services to build a solution that is right for your business needs. </p>
        </li>
        <li>
            <h2><span>Con</span>tact Us</h2>
            <div id='info'>
                <i class="fas fa-map-marker-alt"></i>
                <p> BNR Complex,
                    J.P. Nagar 7th Phase,
                    Bengaluru, Karnataka 560078</p>
            </div>
            <div id='info'>
            <i class="fas fa-phone-alt"></i>
                <p> 080 6841 1700</p>
            </div>
            <div id='info'>
            <i class="far fa-envelope"></i>
                <p>info@techcitisoftware.in</p>
            </div>
            <div id='f_share'>
                <div id='fb'>
                    <a href="#"><i class='fab fa-facebook-f'></i></a>
                </div>
                <div id='gp'>
                    <a href="#"><i class="fab fa-google-plus-g"></i></a>
                </div>
                <div id='li'>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        </li>
        <li>
            <h2><span>Lea</span>ve Your Message</h2>
            <form method="post">
                <div id='f_input'>
                    <i class="fas fa-user"></i>
                    <input type="text" name='query_name' placeholder='Enter Your Name'>
                </div>
                <div id='f_input'>
                    <i class="far fa-envelope"></i>
                    <input type="email" name='query_email' placeholder='Enter Your Email'>
                </div>
                <textarea name="msg" placeholder='Enter Your Message'></textarea>
                <button>Submit</button>
            </form>
        </li>
    </ul>
    <h3>All Rights Reserved To TechCiti Software Consulting Limited Copyright @ 2020 TechCiti Software</h3>
</div>
<div id='home_cat'>
    <h2>Courses Categories</h2>
    <ul>
        <?php echo cat_home(); ?>
        <br clear='all' />
    </ul>
</div>
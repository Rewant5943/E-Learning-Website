<?php
    $con=new pdo("mysql:host=Localhost;dbname=hello","root","");
?>
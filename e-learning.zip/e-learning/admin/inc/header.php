<?php include("inc/function.php"); ?>

<div id='header'>
    <div id='logo'>
        <h2><a href="index.php">TechCiti E-Learning</a></h2>
    </div>
    <div id='title'>
        <h2>Admin Panel of TechCiti E-Learning System</h2>
    
    </div>
    <div id='link'>
        <h3><a href="">LogOut</a></h3>
    </div>
</div>
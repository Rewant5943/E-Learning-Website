<html>
    <head>
        <meta charset="utf-8">
        <title>Admin | Home</title>
        <link rel="stylesheet" href="css/style.css" />
        <script src="https://kit.fontawesome.com/1bf5ec61c2.js" crossorigin="anonymous"></script>

    </head>
    <body>
        <?php 
            include("inc/header.php"); 
            include("inc/bodyleft.php");
            include("inc/bodyright.php");
             

        
        ?>
    </body>
</html>
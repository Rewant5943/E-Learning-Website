<html>
    <head>
        <meta charset="utf-8">
        <title>E-Learning | User</title>
        <link rel="stylesheet" href="css/style.css" />
        <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/1bf5ec61c2.js" crossorigin="anonymous"></script>

    </head>
    <body>
        <?php 
            include("inc/header.php");
        ?>
        <div id='wrap'>
            <div id='user_l'>
                <center><img src="imgs/users/Rewant Pandey.jpeg" alt=""></center>
                <h2>Profile</h2>
                <ul>
                    <li><a href="#"><i class="fas fa-user"></i> My Account</a></li>
                    <li><a href="#"><i class="fas fa-key"></i> Change Password</a></li>
                    <li><a href="#"><i class="fas fa-bookmark"></i> My Courses</a></li>
                </ul>
            </div>
            <div id='user_r'>

            </div>
        </div>
    </body>
</html>